import React from 'react'

export default function Footer() {
  return (
    <>
    <p style={{display:"flex", justifyContent:"center", alignItems:"center", color:" white"}}>
        <a style={{color:"blue"}} href="/">Privacy Policy </a> | Ⓒ 2022 Highradius All Rights Reserved
    </p> 

    </>
  )
}
